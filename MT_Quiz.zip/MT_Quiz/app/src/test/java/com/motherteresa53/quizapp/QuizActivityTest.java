package com.motherteresa53.quizapp;

import org.junit.Test;

import static org.junit.Assert.*;

public class QuizActivityTest {

    @Test
    public void onCreate() {
    }

    @Test
    public void onDestroy() {
    }
}